#!/usr/bin/env python3
from brain_games import cli
import sys
from pprint import pprint


def greet():
    print('Welcome to the Brain Games!')
    pprint(sys.path)


def main():
    greet()
    cli.welcome_user()


if __name__ == '__main__':
    main()
